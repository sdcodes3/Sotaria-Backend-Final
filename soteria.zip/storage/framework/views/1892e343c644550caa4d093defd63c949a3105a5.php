<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?php echo e(asset('js/left-nav.js')); ?>"></script>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<?php echo $__env->yieldContent('script'); ?><?php /**PATH /var/www/html/hiren/reactJs/soteria Update/resources/views/layouts/part/script.blade.php ENDPATH**/ ?>